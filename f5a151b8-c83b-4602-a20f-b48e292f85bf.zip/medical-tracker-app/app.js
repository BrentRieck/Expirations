// Medical Supply Expiration Tracker
// All medical items with categories
const medicalItems = {
    "Tablet/Capsule": [
        { name: "ASPIRIN 81 MG", stockNumber: "4001081" },
        { name: "ASPIRIN 325 MG", stockNumber: "4001325" },
        { name: "ATIVAN 0.5 MG", stockNumber: "4002001" },
        { name: "ATIVAN 1 MG", stockNumber: "4002002" },
        { name: "ATIVAN 2 MG", stockNumber: "4002003" },
        { name: "LORAZEPAM 0.5 MG", stockNumber: "4002004" },
        { name: "LORAZEPAM 1 MG", stockNumber: "4002005" },
        { name: "LORAZEPAM 2 MG", stockNumber: "4002006" },
        { name: "NITROSTAT 0.3 MG", stockNumber: "4003001" },
        { name: "NITROSTAT 0.4 MG", stockNumber: "4003002" },
        { name: "NITROSTAT 0.6 MG", stockNumber: "4003003" },
        { name: "NITRO-BID 2 %", stockNumber: "4003004" },
        { name: "TYLENOL 325 MG", stockNumber: "4004001" },
        { name: "TYLENOL 500 MG", stockNumber: "4004002" },
        { name: "NORCO 5/325 MG", stockNumber: "4004003" },
        { name: "NORCO 7.5/325 MG", stockNumber: "4004004" },
        { name: "NORCO 10/325 MG", stockNumber: "4004005" },
        { name: "VICODIN 5/300 MG", stockNumber: "4004006" },
        { name: "VICODIN 7.5/300 MG", stockNumber: "4004007" },
        { name: "VICODIN 10/300 MG", stockNumber: "4004008" },
        { name: "IBUPROFEN 200 MG", stockNumber: "4005001" },
        { name: "IBUPROFEN 400 MG", stockNumber: "4005002" },
        { name: "IBUPROFEN 600 MG", stockNumber: "4005003" },
        { name: "IBUPROFEN 800 MG", stockNumber: "4005004" },
        { name: "NAPROXEN 250 MG", stockNumber: "4005005" },
        { name: "NAPROXEN 375 MG", stockNumber: "4005006" },
        { name: "NAPROXEN 500 MG", stockNumber: "4005007" },
        { name: "NAPROXEN 550 MG", stockNumber: "4005008" },
        { name: "CARISOPRODOL 350 MG", stockNumber: "4006001" },
        { name: "SOMA 350 MG", stockNumber: "4006002" },
        { name: "TRAZODONE 50 MG", stockNumber: "4007001" },
        { name: "TRAZODONE 100 MG", stockNumber: "4007002" },
        { name: "CYMBALTA 30 MG", stockNumber: "4007003" },
        { name: "CYMBALTA 60 MG", stockNumber: "4007004" },
        { name: "ZYPREXA 5 MG", stockNumber: "4008001" },
        { name: "ZYPREXA 10 MG", stockNumber: "4008002" },
        { name: "ZYPREXA 15 MG", stockNumber: "4008003" },
        { name: "ZYPREXA 20 MG", stockNumber: "4008004" },
        { name: "ABILIFY 10 MG", stockNumber: "4009001" },
        { name: "ABILIFY 15 MG", stockNumber: "4009002" },
        { name: "ABILIFY 20 MG", stockNumber: "4009003" },
        { name: "ABILIFY 30 MG", stockNumber: "4009004" }
    ],
    "Topical": [
        { name: "BENZOIN COMPOUND 2 OZ", stockNumber: "4089088" },
        { name: "BENZOIN COMPOUND 4 OZ", stockNumber: "4089089" },
        { name: "BETADINE 120 ML", stockNumber: "4010001" },
        { name: "BETADINE SWABSTICKS", stockNumber: "4010002" },
        { name: "BACITRACIN 1 OZ", stockNumber: "4010003" },
        { name: "NEOSPORIN 1 OZ", stockNumber: "4010004" },
        { name: "BENADRYL CREAM 1 OZ", stockNumber: "4010005" },
        { name: "HYDROCORTISONE 1% 1 OZ", stockNumber: "4010006" },
        { name: "LOCTITE 1 OZ", stockNumber: "4010007" }
    ],
    "Ophthalmic": [
        { name: "SULFACETAMIDE 10%", stockNumber: "4011001" },
        { name: "TOBRAMYCIN 0.3%", stockNumber: "4011002" },
        { name: "GENTAMYCIN 0.3%", stockNumber: "4011003" },
        { name: "COMBIPOD 1 OZ", stockNumber: "4011004" }
    ],
    "Liquids": [
        { name: "MUCINEX 4 OZ", stockNumber: "4012001" },
        { name: "MUCINEX 8 OZ", stockNumber: "4012002" },
        { name: "ROBITUSSIN 4 OZ", stockNumber: "4012003" },
        { name: "ROBITUSSIN 8 OZ", stockNumber: "4012004" },
        { name: "MAGALDRATE 300 ML", stockNumber: "4012005" },
        { name: "MAGALDRATE 480 ML", stockNumber: "4012006" },
        { name: "MAGALDRATE 120 ML", stockNumber: "4012007" },
        { name: "MAGALDRATE 4 OZ", stockNumber: "4012008" }
    ],
    "Nasal": [
        { name: "NASACORT 120 DOSE", stockNumber: "4013001" }
    ],
    "Respiratory": [
        { name: "ALBUTEROL INHALER", stockNumber: "4014001" },
        { name: "ATROVENT INHALER", stockNumber: "4014002" },
        { name: "COMBO INHALER", stockNumber: "4014003" },
        { name: "EPI PEN", stockNumber: "4014004" }
    ],
    "Insulin": [
        { name: "NOVOLOG FLEXPEN", stockNumber: "4015001" }
    ],
    "Emergency Drug Box": [
        { name: "D50 50 ML", stockNumber: "4089001" },
        { name: "D50 25 ML", stockNumber: "4089002" },
        { name: "D10 100 ML", stockNumber: "4089003" },
        { name: "D10 50 ML", stockNumber: "4089004" },
        { name: "ATROPINE 0.5 MG", stockNumber: "4089005" },
        { name: "ATROPINE 1 MG", stockNumber: "4089006" },
        { name: "LIDOCAINE 100 MG", stockNumber: "4089007" },
        { name: "LIDOCAINE 200 MG", stockNumber: "4089008" },
        { name: "NARCAN 2 MG", stockNumber: "4089009" },
        { name: "NARCAN 4 MG", stockNumber: "4089010" }
    ],
    "Injectable": [
        { name: "METHYLPRED 40 MG", stockNumber: "4089011" },
        { name: "METHYLPRED 125 MG", stockNumber: "4089012" },
        { name: "SOLUMEDROL 40 MG", stockNumber: "4089013" },
        { name: "SOLUMEDROL 125 MG", stockNumber: "4089014" },
        { name: "DECADRON 4 MG", stockNumber: "4089015" },
        { name: "DECADRON 1 MG", stockNumber: "4089016" },
        { name: "BENADRYL 50 MG", stockNumber: "4089017" },
        { name: "TORADOL 30 MG", stockNumber: "4089018" },
        { name: "TORADOL 60 MG", stockNumber: "4089019" },
        { name: "PHENERGAN 25 MG", stockNumber: "4089020" },
        { name: "PHENERGAN 50 MG", stockNumber: "4089021" },
        { name: "DIPHENHYDRAMINE 50 MG", stockNumber: "4089022" },
        { name: "DIPHENHYDRAMINE 25 MG", stockNumber: "4089023" },
        { name: "REGLAN 5 MG", stockNumber: "4089024" },
        { name: "REGLAN 10 MG", stockNumber: "4089025" },
        { name: "ZOFARAN 4 MG", stockNumber: "4089026" },
        { name: "ZOFARAN 8 MG", stockNumber: "4089027" }
    ],
    "Vaccine": [
        { name: "FLUARIX QUADRIVALENT", stockNumber: "4089028" },
        { name: "FLUARIX 2024-2025", stockNumber: "4089029" },
        { name: "FLUARIX 2023-2024", stockNumber: "4089030" },
        { name: "FLUARIX 2022-2023", stockNumber: "4089031" },
        { name: "FLUARIX 2021-2022", stockNumber: "4089032" },
        { name: "FLUARIX 2020-2021", stockNumber: "4089033" },
        { name: "FLUARIX 2019-2020", stockNumber: "4089034" },
        { name: "FLUARIX 2018-2019", stockNumber: "4089035" },
        { name: "FLUARIX 2017-2018", stockNumber: "4089036" },
        { name: "FLUARIX 2016-2017", stockNumber: "4089037" },
        { name: "FLUARIX 2015-2016", stockNumber: "4089038" },
        { name: "FLUARIX 2014-2015", stockNumber: "4089039" },
        { name: "FLUARIX 2013-2014", stockNumber: "4089040" },
        { name: "FLUARIX 2012-2013", stockNumber: "4089041" },
        { name: "FLUARIX 2011-2012", stockNumber: "4089042" },
        { name: "FLUARIX 2010-2011", stockNumber: "4089043" },
        { name: "FLUVIRIN QUADRIVALENT", stockNumber: "4089044" },
        { name: "FLUVIRIN 2024-2025", stockNumber: "4089045" },
        { name: "FLUVIRIN 2023-2024", stockNumber: "4089046" },
        { name: "FLUVIRIN 2022-2023", stockNumber: "4089047" },
        { name: "FLUVIRIN 2021-2022", stockNumber: "4089048" },
        { name: "FLUVIRIN 2020-2021", stockNumber: "4089049" },
        { name: "FLUVIRIN 2019-2020", stockNumber: "4089050" },
        { name: "FLUVIRIN 2018-2019", stockNumber: "4089051" },
        { name: "FLUVIRIN 2017-2018", stockNumber: "4089052" },
        { name: "FLUVIRIN 2016-2017", stockNumber: "4089053" },
        { name: "FLUVIRIN 2015-2016", stockNumber: "4089054" },
        { name: "FLUVIRIN 2014-2015", stockNumber: "4089055" },
        { name: "FLUVIRIN 2013-2014", stockNumber: "4089056" },
        { name: "FLUVIRIN 2012-2013", stockNumber: "4089057" },
        { name: "FLUVIRIN 2011-2012", stockNumber: "4089058" },
        { name: "FLUVIRIN 2010-2011", stockNumber: "4089059" }
    ]
};

// Check authentication
function checkAuth() {
    const session = JSON.parse(localStorage.getItem('userSession'));
    
    if (!session) {
        // No session, redirect to login
        window.location.href = 'login.html';
        return null;
    }
    
    return session;
}

// Logout function
function logout() {
    localStorage.removeItem('userSession');
    localStorage.removeItem('selectedOffice');
    window.location.href = 'login.html';
}

// Navigate to office selector
function goToOfficeSelector() {
    window.location.href = 'office-selector.html';
}

// Navigate to user management
function goToUserManagement() {
    window.location.href = 'user-management.html';
}

// Get current office data
function getCurrentOfficeData() {
    const selectedOffice = localStorage.getItem('selectedOffice');
    if (!selectedOffice) {
        // Redirect to office selector if no office is selected
        window.location.href = 'office-selector.html';
        return null;
    }
    
    const officeData = JSON.parse(localStorage.getItem('officeData')) || {};
    return {
        officeName: selectedOffice,
        items: officeData[selectedOffice] || {}
    };
}

// Save office data
function saveOfficeData(officeName, items) {
    const officeData = JSON.parse(localStorage.getItem('officeData')) || {};
    officeData[officeName] = items;
    localStorage.setItem('officeData', JSON.stringify(officeData));
}

// Add expiration date for an item
function addExpirationDate(stockNumber) {
    // Get session to check if user can edit
    const session = checkAuth();
    const readOnly = session && session.username === 'guest';
    
    if (readOnly) {
        alert('Guest mode: Cannot add expiration dates');
        return;
    }
    
    const officeData = getCurrentOfficeData();
    if (!officeData) return;
    
    const itemData = officeData.items[stockNumber] || { expirationDates: [] };
    itemData.expirationDates.push({ id: Date.now(), date: "" });
    officeData.items[stockNumber] = itemData;
    
    saveOfficeData(officeData.officeName, officeData.items);
    renderItems();
}

// Remove expiration date for an item
function removeExpirationDate(stockNumber, dateId) {
    // Get session to check if user can edit
    const session = checkAuth();
    const readOnly = session && session.username === 'guest';
    
    if (readOnly) {
        alert('Guest mode: Cannot remove expiration dates');
        return;
    }
    
    const officeData = getCurrentOfficeData();
    if (!officeData) return;
    
    const itemData = officeData.items[stockNumber];
    if (itemData) {
        itemData.expirationDates = itemData.expirationDates.filter(date => date.id !== dateId);
        officeData.items[stockNumber] = itemData;
        saveOfficeData(officeData.officeName, officeData.items);
        renderItems();
    }
}

// Update expiration date for an item
function updateExpirationDate(stockNumber, dateId, newDate) {
    // Get session to check if user can edit
    const session = checkAuth();
    const readOnly = session && session.username === 'guest';
    
    if (readOnly) {
        alert('Guest mode: Cannot update expiration dates');
        return;
    }
    
    const officeData = getCurrentOfficeData();
    if (!officeData) return;
    
    const itemData = officeData.items[stockNumber];
    if (itemData) {
        const dateEntry = itemData.expirationDates.find(date => date.id === dateId);
        if (dateEntry) {
            dateEntry.date = newDate;
            saveOfficeData(officeData.officeName, officeData.items);
            updateStatistics();
        }
    }
}

// Get status for an expiration date
function getExpirationStatus(dateStr) {
    if (!dateStr) return 'no-date';
    
    const expDate = new Date(dateStr);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (expDate < today) {
        return 'expired';
    }
    
    const diffTime = expDate - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 30) {
        return 'soon';
    }
    
    return 'good';
}

// Get status emoji for an expiration date
function getExpirationStatusEmoji(status) {
    switch (status) {
        case 'expired': return '⚠️';
        case 'soon': return '⏰';
        case 'good': return '✓';
        case 'no-date': return '📅';
        default: return '📅';
    }
}

// Get status text for an expiration date
function getExpirationStatusText(status) {
    switch (status) {
        case 'expired': return 'Expired';
        case 'soon': return 'Expiring Soon';
        case 'good': return 'Good';
        case 'no-date': return 'No Date';
        default: return 'Unknown';
    }
}

// Update statistics
function updateStatistics() {
    const officeData = getCurrentOfficeData();
    if (!officeData) return;
    
    let expiredCount = 0;
    let soonCount = 0;
    let goodCount = 0;
    let noDateCount = 0;
    
    Object.values(officeData.items).forEach(item => {
        if (item.expirationDates && item.expirationDates.length > 0) {
            item.expirationDates.forEach(dateEntry => {
                const status = getExpirationStatus(dateEntry.date);
                switch (status) {
                    case 'expired': expiredCount++; break;
                    case 'soon': soonCount++; break;
                    case 'good': goodCount++; break;
                    case 'no-date': noDateCount++; break;
                }
            });
        } else {
            noDateCount++;
        }
    });
    
    document.getElementById('expiredCount').textContent = expiredCount;
    document.getElementById('soonCount').textContent = soonCount;
    document.getElementById('goodCount').textContent = goodCount;
    document.getElementById('noDateCount').textContent = noDateCount;
    
    // Update office name display
    document.getElementById('officeName').textContent = officeData.officeName;
}

// Render items for selected category
function renderItems() {
    const categorySelect = document.getElementById('categorySelect');
    const selectedCategory = categorySelect.value;
    
    const itemSelect = document.getElementById('itemSelect');
    itemSelect.innerHTML = '<option value="">-- Select an Item --</option>';
    
    const container = document.getElementById('expirationContainer');
    container.innerHTML = '';
    
    // Get session to determine if in read-only mode
    const session = checkAuth();
    const readOnly = session && session.username === 'guest';
    
    // Update UI based on read-only status
    const addButton = document.getElementById('addItemBtn');
    if (addButton) {
        if (readOnly) {
            addButton.disabled = true;
            addButton.textContent = '🔒 Add Selected Item (Read-Only)';
        } else {
            addButton.disabled = false;
            addButton.textContent = '➕ Add Selected Item';
        }
    }
    
    // Add items to dropdown
    if (selectedCategory && medicalItems[selectedCategory]) {
        medicalItems[selectedCategory].forEach(item => {
            const option = document.createElement('option');
            option.value = item.stockNumber;
            option.textContent = `${item.name} (${item.stockNumber})`;
            itemSelect.appendChild(option);
        });
    }
    
    // Get current office data
    const officeData = getCurrentOfficeData();
    if (!officeData) return;
    
    // Render expiration dates for all items in this office
    Object.entries(officeData.items).forEach(([stockNumber, itemData]) => {
        // Find the item in our medicalItems data
        let item = null;
        let categoryName = null;
        
        for (const [category, items] of Object.entries(medicalItems)) {
            const foundItem = items.find(i => i.stockNumber === stockNumber);
            if (foundItem) {
                item = foundItem;
                categoryName = category;
                break;
            }
        }
        
        if (item) {
            const itemCard = document.createElement('div');
            itemCard.className = 'item-card';
            
            // Create expiration date entries
            let expirationHTML = '';
            if (itemData.expirationDates && itemData.expirationDates.length > 0) {
                itemData.expirationDates.forEach(dateEntry => {
                    const status = getExpirationStatus(dateEntry.date);
                    const statusEmoji = getExpirationStatusEmoji(status);
                    const statusText = getExpirationStatusText(status);
                    
                    expirationHTML += `
                        <div class="expiration-entry">
                            <div class="expiration-input">
                                <input type="date" 
                                       id="date-${stockNumber}-${dateEntry.id}" 
                                       value="${dateEntry.date}" 
                                       onchange="updateExpirationDate('${stockNumber}', ${dateEntry.id}, this.value)"
                                       ${readOnly ? 'disabled' : ''}>
                                <span class="status-badge ${status}" title="${statusText}">
                                    ${statusEmoji}
                                </span>
                            </div>
                            ${!readOnly ? 
                                `<button class="btn btn-danger btn-small" onclick="removeExpirationDate('${stockNumber}', ${dateEntry.id})">🗑️</button>` : 
                                `<button class="btn btn-secondary btn-small" disabled>🔒</button>`}
                        </div>
                    `;
                });
            } else {
                expirationHTML += `
                    <div class="expiration-entry">
                        <div class="expiration-input">
                            <input type="date" disabled>
                            <span class="status-badge no-date" title="No Date">📅</span>
                        </div>
                        ${!readOnly ? 
                            `<button class="btn btn-danger btn-small" onclick="removeExpirationDate('${stockNumber}', 0)">🗑️</button>` : 
                            `<button class="btn btn-secondary btn-small" disabled>🔒</button>`}
                    </div>
                `;
            }
            
            itemCard.innerHTML = `
                <div class="item-header">
                    <div class="item-name">${item.name}</div>
                    <div class="item-stock">(${item.stockNumber})</div>
                </div>
                <div class="item-category">${categoryName}</div>
                <div class="expiration-list">
                    ${expirationHTML}
                </div>
                ${!readOnly ? 
                    `<div class="item-actions">
                        <button class="btn btn-secondary btn-small" onclick="addExpirationDate('${item.stockNumber}')">➕ Add Date</button>
                    </div>` : 
                    `<div class="item-actions">
                        <button class="btn btn-secondary btn-small" disabled>🔒 Add Date</button>
                    </div>`}
            `;
            
            container.appendChild(itemCard);
        }
    });
    
    updateStatistics();
}

// Add selected item to tracking
function addItemToTracking() {
    const itemSelect = document.getElementById('itemSelect');
    const selectedStockNumber = itemSelect.value;
    
    // Get session to check if user can edit
    const session = checkAuth();
    const readOnly = session && session.username === 'guest';
    
    if (readOnly) {
        alert('Guest mode: Cannot add items');
        return;
    }
    
    if (!selectedStockNumber) {
        alert('Please select an item first');
        return;
    }
    
    const officeData = getCurrentOfficeData();
    if (!officeData) return;
    
    // Initialize item data if it doesn't exist
    if (!officeData.items[selectedStockNumber]) {
        officeData.items[selectedStockNumber] = { expirationDates: [] };
    }
    
    saveOfficeData(officeData.officeName, officeData.items);
    renderItems();
}

// Filter items based on search
function filterItems() {
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const itemSelect = document.getElementById('itemSelect');
    
    // Clear existing options
    itemSelect.innerHTML = '<option value="">-- Select an Item --</option>';
    
    const categorySelect = document.getElementById('categorySelect');
    const selectedCategory = categorySelect.value;
    
    if (selectedCategory && medicalItems[selectedCategory]) {
        medicalItems[selectedCategory].forEach(item => {
            if (item.name.toLowerCase().includes(searchInput) || 
                item.stockNumber.includes(searchInput)) {
                const option = document.createElement('option');
                option.value = item.stockNumber;
                option.textContent = `${item.name} (${item.stockNumber})`;
                itemSelect.appendChild(option);
            }
        });
    }
}

// Export all data
function exportAllData() {
    const data = {
        appUsers: JSON.parse(localStorage.getItem('appUsers')) || [],
        officeData: JSON.parse(localStorage.getItem('officeData')) || {},
        userSession: JSON.parse(localStorage.getItem('userSession')) || null
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(dataBlob);
    link.download = 'medical-tracker-data.json';
    link.click();
}

// Export current office data
function exportOfficeData() {
    const officeData = getCurrentOfficeData();
    if (!officeData) return;
    
    // Create a simplified export with just the current office data
    const exportData = {
        officeName: officeData.officeName,
        items: officeData.items
    };
    
    const dataStr = JSON.stringify(exportData, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(dataBlob);
    link.download = `medical-tracker-${officeData.officeName.replace(/\s+/g, '-')}.json`;
    link.click();
}

// Export to CSV
function exportToCSV() {
    const officeData = getCurrentOfficeData();
    if (!officeData) return;
    
    let csvContent = "Item Name,Stock Number,Category,Expiration Date,Status\n";
    
    Object.entries(officeData.items).forEach(([stockNumber, itemData]) => {
        // Find the item in our medicalItems data
        let item = null;
        let categoryName = null;
        
        for (const [category, items] of Object.entries(medicalItems)) {
            const foundItem = items.find(i => i.stockNumber === stockNumber);
            if (foundItem) {
                item = foundItem;
                categoryName = category;
                break;
            }
        }
        
        if (item) {
            if (itemData.expirationDates && itemData.expirationDates.length > 0) {
                itemData.expirationDates.forEach(dateEntry => {
                    const status = getExpirationStatus(dateEntry.date);
                    const statusText = getExpirationStatusText(status);
                    csvContent += `"${item.name}",${item.stockNumber},"${categoryName}",${dateEntry.date || 'N/A'},${statusText}\n`;
                });
            } else {
                csvContent += `"${item.name}",${item.stockNumber},"${categoryName}",N/A,No Date\n`;
            }
        }
    });
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `medical-tracker-${officeData.officeName.replace(/\s+/g, '-')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Import data function
function importData(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);
            
            // Check if this is a full data export or just office data
            if (data.appUsers && data.officeData) {
                // Full data export - restore everything
                if (data.appUsers) {
                    localStorage.setItem('appUsers', JSON.stringify(data.appUsers));
                }
                
                if (data.officeData) {
                    localStorage.setItem('officeData', JSON.stringify(data.officeData));
                }
                
                if (data.userSession) {
                    localStorage.setItem('userSession', JSON.stringify(data.userSession));
                }
                
                alert('All data imported successfully!');
            } else if (data.officeName && data.items) {
                // Office data export - just restore this office's data
                const officeData = JSON.parse(localStorage.getItem('officeData')) || {};
                officeData[data.officeName] = data.items;
                localStorage.setItem('officeData', JSON.stringify(officeData));
                
                alert(`Office data for "${data.officeName}" imported successfully!`);
            } else {
                alert('Invalid data format');
                return;
            }
            
            // Refresh the page to show updated data
            location.reload();
        } catch (error) {
            alert('Error importing data: ' + error.message);
        }
    };
    
    reader.readAsText(file);
}

// Export to JSON
function exportToJSON() {
    const officeData = getCurrentOfficeData();
    if (!officeData) return;
    
    // Create a more readable export format
    const exportData = {
        officeName: officeData.officeName,
        exportDate: new Date().toISOString(),
        items: []
    };
    
    Object.entries(officeData.items).forEach(([stockNumber, itemData]) => {
        // Find the item in our medicalItems data
        let item = null;
        let categoryName = null;
        
        for (const [category, items] of Object.entries(medicalItems)) {
            const foundItem = items.find(i => i.stockNumber === stockNumber);
            if (foundItem) {
                item = foundItem;
                categoryName = category;
                break;
            }
        }
        
        if (item) {
            const itemExport = {
                name: item.name,
                stockNumber: item.stockNumber,
                category: categoryName,
                expirationDates: itemData.expirationDates || []
            };
            exportData.items.push(itemExport);
        }
    });
    
    const dataStr = JSON.stringify(exportData, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(dataBlob);
    link.download = `medical-tracker-${officeData.officeName.replace(/\s+/g, '-')}.json`;
    link.click();
}

// Initialize the app
function initializeApp() {
    // Check authentication first
    const session = checkAuth();
    if (!session) return;
    
    // Update UI based on user role
    const userManagementBtn = document.getElementById('userManagementBtn');
    const syncControls = document.getElementById('syncControls');
    
    if (userManagementBtn && syncControls) {
        if (session.role === 'admin') {
            userManagementBtn.style.display = 'inline-block';
            syncControls.style.display = 'block';
        } else {
            userManagementBtn.style.display = 'none';
            syncControls.style.display = 'none';
        }
    }
    
    // Update user info display
    const userInfo = document.getElementById('userInfo');
    if (userInfo) {
        userInfo.textContent = session.username === 'guest' ? 
            'Viewing as: Guest (Read-Only)' : 
            `Logged in as: ${session.username} (${session.role})`;
    }
    
    // Populate categories dropdown
    const categorySelect = document.getElementById('categorySelect');
    Object.keys(medicalItems).forEach(category => {
        const option = document.createElement('option');
        option.value = category;
        option.textContent = category;
        categorySelect.appendChild(option);
    });
    
    // Render items
    renderItems();
}

// Event listener for page load
document.addEventListener('DOMContentLoaded', initializeApp);

// Event listener for category change
document.getElementById('categorySelect').addEventListener('change', renderItems);

// Event listener for search input
document.getElementById('searchInput').addEventListener('input', filterItems);