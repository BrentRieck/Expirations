// Cross-device synchronization functions

// Sync user data across devices when admin logs in
function syncUserDataAcrossDevices() {
    // Get current users from localStorage
    const localUsers = JSON.parse(localStorage.getItem('appUsers')) || [];
    
    // For this implementation, we'll use a simple approach:
    // When an admin logs in, we'll ensure the default admin account exists
    // and preserve any additional users that were added
    // In a production environment, this would connect to a real backend service
    
    // Check if we have the default admin account
    const hasDefaultAdmin = localUsers.some(user => user.username === 'admin');
    
    if (!hasDefaultAdmin) {
        // Add default admin account if it doesn't exist
        const defaultAdmin = {
            username: 'admin',
            password: 'admin123',
            role: 'admin',
            createdAt: new Date().toISOString()
        };
        
        localUsers.unshift(defaultAdmin);
        localStorage.setItem('appUsers', JSON.stringify(localUsers));
    }
}

// Initialize user data sync
function initializeUserDataSync() {
    // This function would typically connect to a backend service
    // For our purposes, we'll ensure the default admin always exists
    syncUserDataAcrossDevices();
}

// Export data function
function exportAllData() {
    const data = {
        appUsers: JSON.parse(localStorage.getItem('appUsers')) || [],
        officeData: JSON.parse(localStorage.getItem('officeData')) || {},
        userSession: JSON.parse(localStorage.getItem('userSession')) || null
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(dataBlob);
    link.download = 'medical-tracker-data.json';
    link.click();
}

// Import data function
function importAllData(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);
            
            // Restore users
            if (data.appUsers) {
                localStorage.setItem('appUsers', JSON.stringify(data.appUsers));
            }
            
            // Restore office data
            if (data.officeData) {
                localStorage.setItem('officeData', JSON.stringify(data.officeData));
            }
            
            // Restore session if it exists
            if (data.userSession) {
                localStorage.setItem('userSession', JSON.stringify(data.userSession));
            }
            
            alert('Data imported successfully!');
            
            // Refresh the page to show updated data
            location.reload();
        } catch (error) {
            alert('Error importing data: ' + error.message);
        }
    };
    
    reader.readAsText(file);
}