// Check authentication and ensure user is admin
function checkAuth() {
    const session = JSON.parse(localStorage.getItem('userSession'));
    
    if (!session || !session.loggedIn) {
        // No session, redirect to login
        window.location.href = 'login.html';
        return false;
    }
    
    if (session.role !== 'admin') {
        // Not admin, redirect to office selector
        window.location.href = 'office-selector.html';
        return false;
    }
    
    // Update user info
    document.getElementById('userInfo').textContent = `Logged in as: ${session.username} (${session.role})`;
    
    return session;
}

// Logout function
function logout() {
    localStorage.removeItem('userSession');
    window.location.href = 'login.html';
}

// Navigate to office selector
function goToOfficeSelector() {
    window.location.href = 'office-selector.html';
}

// Add a new user
function addUser() {
    const username = document.getElementById('newUsername').value.trim();
    const password = document.getElementById('newPassword').value;
    const role = document.getElementById('userRole').value;
    const messageElement = document.getElementById('userMessage');
    
    // Clear previous messages
    messageElement.style.display = 'none';
    
    // Validate input
    if (!username || !password) {
        showMessage('Please fill in all fields', 'error');
        return;
    }
    
    if (password.length < 6) {
        showMessage('Password must be at least 6 characters long', 'error');
        return;
    }
    
    // Get existing users
    let users = JSON.parse(localStorage.getItem('appUsers')) || [];
    
    // Check if user already exists
    if (users.some(user => user.username === username)) {
        showMessage('A user with this username already exists', 'error');
        return;
    }
    
    // Add new user
    const newUser = {
        username: username,
        password: password,
        role: role,
        createdAt: new Date().toISOString()
    };
    
    users.push(newUser);
    localStorage.setItem('appUsers', JSON.stringify(users));
    
    // Clear form
    document.getElementById('newUsername').value = '';
    document.getElementById('newPassword').value = '';
    
    // Show success message
    showMessage(`User "${username}" added successfully`, 'success');
    
    // Refresh user list
    renderUsers();
}

// Remove a user
function removeUser(username) {
    if (username === 'admin') {
        showMessage('Cannot remove the admin account', 'error');
        return;
    }
    
    if (confirm(`Are you sure you want to remove user "${username}"?`)) {
        // Get existing users
        let users = JSON.parse(localStorage.getItem('appUsers')) || [];
        
        // Remove user
        users = users.filter(user => user.username !== username);
        localStorage.setItem('appUsers', JSON.stringify(users));
        
        // Refresh user list
        renderUsers();
    }
}

// Show message
function showMessage(message, type) {
    const messageElement = document.getElementById('userMessage');
    messageElement.textContent = message;
    messageElement.style.display = 'block';
    
    if (type === 'error') {
        messageElement.style.background = '#f8d7da';
        messageElement.style.color = '#721c24';
        messageElement.style.borderColor = '#f5c6cb';
    } else {
        messageElement.style.background = '#d4edda';
        messageElement.style.color = '#155724';
        messageElement.style.borderColor = '#c3e6cb';
    }
    
    // Auto-hide message after 5 seconds
    setTimeout(() => {
        messageElement.style.display = 'none';
    }, 5000);
}

// Render users
function renderUsers() {
    const container = document.getElementById('usersContainer');
    container.innerHTML = '';
    
    // Get users
    const users = JSON.parse(localStorage.getItem('appUsers')) || [];
    
    if (users.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div style="font-size: 4em; margin-bottom: 20px;">👥</div>
                <h3>No users found</h3>
                <p>Add your first user account</p>
            </div>
        `;
        return;
    }
    
    // Render each user
    users.forEach(user => {
        const userCard = document.createElement('div');
        userCard.className = 'user-card';
        userCard.innerHTML = `
            <div class="item-header">
                <div class="item-name">${user.username}</div>
                <span class="status-badge ${user.role === 'admin' ? 'expired' : 'good'}">
                    ${user.role === 'admin' ? 'Admin' : 'User'}
                </span>
            </div>
            <div class="item-details">
                <div class="item-detail">
                    <label>Role:</label>
                    <span>${user.role}</span>
                </div>
                <div class="item-detail">
                    <label>Created:</label>
                    <span>${new Date(user.createdAt).toLocaleDateString()}</span>
                </div>
            </div>
            ${user.username !== 'admin' ? 
                `<div class="office-actions">
                    <button class="btn btn-danger btn-small" onclick="removeUser('${user.username}')">🗑️ Remove</button>
                </div>` : 
                `<div class="office-actions">
                    <button class="btn btn-secondary btn-small" disabled>Protected Account</button>
                </div>`}
        `;
        container.appendChild(userCard);
    });
}

// Export data function
function exportData() {
    const data = {
        appUsers: JSON.parse(localStorage.getItem('appUsers')) || [],
        officeData: JSON.parse(localStorage.getItem('officeData')) || {},
        userSession: JSON.parse(localStorage.getItem('userSession')) || null
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(dataBlob);
    link.download = 'medical-tracker-data.json';
    link.click();
}

// Import data function
function importData(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);
            
            // Restore users
            if (data.appUsers) {
                localStorage.setItem('appUsers', JSON.stringify(data.appUsers));
            }
            
            // Restore office data
            if (data.officeData) {
                localStorage.setItem('officeData', JSON.stringify(data.officeData));
            }
            
            // Restore session if it exists
            if (data.userSession) {
                localStorage.setItem('userSession', JSON.stringify(data.userSession));
            }
            
            alert('Data imported successfully!');
            
            // Refresh the page to show updated data
            location.reload();
        } catch (error) {
            alert('Error importing data: ' + error.message);
        }
    };
    
    reader.readAsText(file);
}

// Initialize the user management page
function initializeUserManagement() {
    // Check authentication first
    const session = checkAuth();
    if (!session) return;
    
    renderUsers();
}

// Run initialization when page loads
document.addEventListener('DOMContentLoaded', initializeUserManagement);