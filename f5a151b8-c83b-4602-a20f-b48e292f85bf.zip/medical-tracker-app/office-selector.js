// Check authentication
function checkAuth() {
    const session = JSON.parse(localStorage.getItem('userSession'));
    
    if (!session) {
        // No session, redirect to login
        window.location.href = 'login.html';
        return null;
    }
    
    // Update user info
    const userInfo = document.getElementById('userInfo');
    if (userInfo) {
        userInfo.textContent = session.username === 'guest' ? 
            'Viewing as: Guest (Read-Only)' : 
            `Logged in as: ${session.username} (${session.role})`;
    }
    
    // Show/hide user management button based on role
    const userManagementBtn = document.getElementById('userManagementBtn');
    if (userManagementBtn) {
        if (session.role === 'admin') {
            userManagementBtn.style.display = 'inline-block';
        } else {
            userManagementBtn.style.display = 'none';
        }
    }
    
    // Show/hide sync controls based on role
    const syncControls = document.getElementById('syncControls');
    if (syncControls) {
        if (session.role === 'admin') {
            syncControls.style.display = 'block';
        } else {
            syncControls.style.display = 'none';
        }
    }
    
    return session;
}

// Logout function
function logout() {
    localStorage.removeItem('userSession');
    window.location.href = 'login.html';
}

// Navigate to user management
function goToUserManagement() {
    window.location.href = 'user-management.html';
}

// Add a new office
function addOffice() {
    const officeName = document.getElementById('officeName').value.trim();
    const messageElement = document.getElementById('officeMessage');
    
    // Clear previous messages
    messageElement.style.display = 'none';
    
    // Validate input
    if (!officeName) {
        showMessage('Please enter an office name', 'error');
        return;
    }
    
    // Get session to check if user can edit
    const session = checkAuth();
    const readOnly = session && session.username === 'guest';
    
    if (readOnly) {
        showMessage('Guest mode: Cannot add offices', 'error');
        return;
    }
    
    // Get existing offices
    let officeData = JSON.parse(localStorage.getItem('officeData')) || {};
    
    // Check if office already exists
    if (officeData[officeName]) {
        showMessage('An office with this name already exists', 'error');
        return;
    }
    
    // Add new office with empty data
    officeData[officeName] = {};
    localStorage.setItem('officeData', JSON.stringify(officeData));
    
    // Clear form
    document.getElementById('officeName').value = '';
    
    // Show success message
    showMessage(`Office "${officeName}" added successfully`, 'success');
    
    // Refresh office list
    renderOffices();
}

// Remove an office
function removeOffice(officeName) {
    // Get session to check if user can edit
    const session = checkAuth();
    const readOnly = session && session.username === 'guest';
    
    if (readOnly) {
        showMessage('Guest mode: Cannot remove offices', 'error');
        return;
    }
    
    if (confirm(`Are you sure you want to remove office "${officeName}"? All data for this office will be lost.`)) {
        // Get existing offices
        let officeData = JSON.parse(localStorage.getItem('officeData')) || {};
        
        // Remove office
        delete officeData[officeName];
        localStorage.setItem('officeData', JSON.stringify(officeData));
        
        // Refresh office list
        renderOffices();
    }
}

// Select an office
function selectOffice(officeName) {
    // Save selected office to localStorage
    localStorage.setItem('selectedOffice', officeName);
    
    // Redirect to main tracker
    window.location.href = 'index.html';
}

// Show message
function showMessage(message, type) {
    const messageElement = document.getElementById('officeMessage');
    messageElement.textContent = message;
    messageElement.style.display = 'block';
    
    if (type === 'error') {
        messageElement.style.background = '#f8d7da';
        messageElement.style.color = '#721c24';
        messageElement.style.borderColor = '#f5c6cb';
    } else {
        messageElement.style.background = '#d4edda';
        messageElement.style.color = '#155724';
        messageElement.style.borderColor = '#c3e6cb';
    }
    
    // Auto-hide message after 5 seconds
    setTimeout(() => {
        messageElement.style.display = 'none';
    }, 5000);
}

// Render offices
function renderOffices() {
    const container = document.getElementById('officesContainer');
    container.innerHTML = '';
    
    // Get session to determine if in read-only mode
    const session = checkAuth();
    const readOnly = session && session.username === 'guest';
    
    // Get offices
    const officeData = JSON.parse(localStorage.getItem('officeData')) || {};
    const officeNames = Object.keys(officeData);
    
    if (officeNames.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div style="font-size: 4em; margin-bottom: 20px;">🏢</div>
                <h3>No offices found</h3>
                <p>${readOnly ? 'No offices have been set up yet' : 'Add your first office location'}</p>
            </div>
        `;
        return;
    }
    
    // Render each office
    officeNames.forEach(officeName => {
        const officeCard = document.createElement('div');
        officeCard.className = 'office-card';
        officeCard.innerHTML = `
            <div class="office-header">
                <div class="office-name">${officeName}</div>
            </div>
            <div class="office-actions">
                <button class="btn btn-primary" onclick="selectOffice('${officeName}')">📋 Select</button>
                ${!readOnly ? 
                    `<button class="btn btn-danger btn-small" onclick="removeOffice('${officeName}')">🗑️ Remove</button>` : 
                    `<button class="btn btn-secondary btn-small" disabled>🔒 Read-Only</button>`}
            </div>
        `;
        container.appendChild(officeCard);
    });
}

// Export data function
function exportData() {
    const data = {
        appUsers: JSON.parse(localStorage.getItem('appUsers')) || [],
        officeData: JSON.parse(localStorage.getItem('officeData')) || {},
        userSession: JSON.parse(localStorage.getItem('userSession')) || null
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(dataBlob);
    link.download = 'medical-tracker-data.json';
    link.click();
}

// Import data function
function importData(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const data = JSON.parse(e.target.result);
            
            // Restore users
            if (data.appUsers) {
                localStorage.setItem('appUsers', JSON.stringify(data.appUsers));
            }
            
            // Restore office data
            if (data.officeData) {
                localStorage.setItem('officeData', JSON.stringify(data.officeData));
            }
            
            // Restore session if it exists
            if (data.userSession) {
                localStorage.setItem('userSession', JSON.stringify(data.userSession));
            }
            
            alert('Data imported successfully!');
            
            // Refresh the page to show updated data
            location.reload();
        } catch (error) {
            alert('Error importing data: ' + error.message);
        }
    };
    
    reader.readAsText(file);
}

// Initialize with a default office if none exists
function initializeDefaultOffice() {
    let officeData = JSON.parse(localStorage.getItem('officeData')) || {};
    
    // Check if we have any offices
    if (Object.keys(officeData).length === 0) {
        // Initialize with default office
        officeData['MVHS New Hartford Medical Office'] = {};
        localStorage.setItem('officeData', JSON.stringify(officeData));
        return true;
    }
    
    return false;
}

// Initialize the office selector page
function initializeOfficeSelector() {
    // Check authentication first
    const session = checkAuth();
    if (!session) return;
    
    // Initialize default office if needed
    initializeDefaultOffice();
    
    // Render offices
    renderOffices();
}

// Run initialization when page loads
document.addEventListener('DOMContentLoaded', initializeOfficeSelector);