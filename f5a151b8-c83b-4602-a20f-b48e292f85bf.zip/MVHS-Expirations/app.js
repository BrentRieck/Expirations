// Medical Supply Items Database - Updated from user's list
const medicalItems = [
    // TABLET/CAPSULE
    { stockNumber: '4085010', name: 'ACETAMINOPHEN 325 MG TABLET/CAP', category: 'tablet-capsule', form: 'CL', packSize: '1', par: '4' },
    { stockNumber: '4085117', name: 'ASPIRIN 81 MG CHEWABLE', category: 'tablet-capsule', form: 'CW', packSize: '1', par: '4' },
    { stockNumber: '4085114', name: 'ASPIRIN EC 325 MG TABLET/CAP', category: 'tablet-capsule', form: 'TB', packSize: '1', par: '2' },
    { stockNumber: '4085353', name: 'CLONIDINE 0.1 MG', category: 'tablet-capsule', form: 'TB', packSize: '1', par: '4' },
    { stockNumber: '4085755', name: 'IBUPROFEN 200MG', category: 'tablet-capsule', form: 'TB', packSize: '1', par: '2' },
    { stockNumber: '4085998', name: 'METOPROLOL TARTRATE 50 MG', category: 'tablet-capsule', form: 'TB', packSize: '1', par: '4' },
    { stockNumber: '4086147', name: 'ONDANSETRON ODT 4 MG', category: 'tablet-capsule', form: 'TB', packSize: '1', par: '4' },

    // TOPICAL
    { stockNumber: '4089088', name: 'BENZOIN COMPOUND 2 OZ', category: 'topical', form: 'TN', packSize: '1', par: '1' },
    { stockNumber: '4080435', name: 'ETHYL CHLORIDE MD STREAM', category: 'topical', form: 'SP', packSize: '1', par: '1' },
    { stockNumber: '4080590', name: 'IMEDIHONEY', category: 'topical', form: 'GEL', packSize: '1', par: '1' },
    { stockNumber: '4080817', name: 'SILVER SULFADIAZINE 1% 25 GM', category: 'topical', form: 'CR', packSize: '1', par: '1' },
    { stockNumber: '4086439', name: 'SILVER NITRATE APPLICATOR', category: 'topical', form: 'ST', packSize: '10', par: '2' },

    // OPHTHALMIC
    { stockNumber: '4080464', name: 'EYE WASH 40z', category: 'ophthalmic', form: 'SL', packSize: '1', par: '2' },
    { stockNumber: '4085645', name: 'FLUORESCEIN OPHTH STRIPS', category: 'ophthalmic', form: 'SI', packSize: '1', par: '10' },

    // LIQUIDS
    { stockNumber: '4081137', name: 'ACETAMINOPHEN 160MG/5ML UD CUPS', category: 'liquids', form: 'SS', packSize: '1', par: '3' },
    { stockNumber: '4081142', name: 'DIPHENHYDRAMINE 12.5MG/5ML UD CUP', category: 'liquids', form: 'LQ', packSize: '1', par: '3' },
    { stockNumber: '4081145', name: 'IBUPROFEN 100MG/5 ML UD CUPS', category: 'liquids', form: 'SS', packSize: '1', par: '3' },
    { stockNumber: '4080561', name: 'LIDOCAINE 2% VISCOUS UD CUPS', category: 'liquids', form: 'LQ', packSize: '1', par: '2' },
    { stockNumber: '4080972', name: 'MAALOX PLUS UD CUPS', category: 'liquids', form: 'LQ', packSize: '1', par: '2' },

    // NASAL
    { stockNumber: '4089346', name: 'NASAL EPINEPHRINE 10 ML', category: 'nasal', form: 'LQ', packSize: '1', par: '1' },

    // RESPIRATORY
    { stockNumber: '4080892', name: 'ALBUTEROL SULF 0.083% 3 ML', category: 'respiratory', form: 'SL', packSize: '1', par: '5' },
    { stockNumber: '4080903', name: 'ALBUTEROL/IPRATROPIUM 2.5-0.5 MG/3 ML', category: 'respiratory', form: 'AM', packSize: '1', par: '5' },
    { stockNumber: '4081245', name: 'SODIUM CHLORIDE 0.9% 5 ML', category: 'respiratory', form: 'AM', packSize: '1', par: '10' },

    // INSULIN
    { stockNumber: '4080902', name: 'HUMULIN R 100 U/ML 3 ML', category: 'insulin', form: 'MD', packSize: '1', par: '1' },

    // EMERGENCY DRUG BOX MEDS
    { stockNumber: '4085117-E', name: 'ASPIRIN 81 MG CHEWABLE (Emergency Drug Box)', category: 'emergency', form: 'CW', packSize: '1', par: '4' },
    { stockNumber: '4080111', name: 'DIPHENHYDRAMINE 50 MG/ML 1 ML VIAL', category: 'emergency', form: 'SD', packSize: '1', par: '1' },
    { stockNumber: '4085541', name: 'EPIPEN AUTO-INJECTOR 0.3 MG', category: 'emergency', form: 'SY', packSize: '1', par: '2' },
    { stockNumber: '4085540', name: 'EPIPEN JR AUTO-INJECTOR 0.15 MG', category: 'emergency', form: 'SY', packSize: '1', par: '2' },
    { stockNumber: '4085696', name: 'GLUCAGEN 1MG POWDER VIAL', category: 'emergency', form: 'VIAL', packSize: '1', par: '1' },
    { stockNumber: '4085982', name: 'METHYLPREDNISOLONE SOD SUCC 125 MG', category: 'emergency', form: 'SD', packSize: '1', par: '1' },
    { stockNumber: '4082007', name: 'NALOXONE 4MG NASAL SPRAY', category: 'emergency', form: 'SPIN', packSize: '1', par: '2' },
    { stockNumber: '4086707', name: 'NITROGLYCERIN 0.4 MG', category: 'emergency', form: 'TB', packSize: 'BTL/25', par: '1' },
    { stockNumber: '4083166', name: 'ORAL GLUCOSE GEL', category: 'emergency', form: 'GEL', packSize: '1', par: '2' },

    // INJECTABLE
    { stockNumber: '', name: 'CEFTRIAXONE 500MG IM/IV', category: 'injectable', form: 'SD', packSize: '1', par: '2' },
    { stockNumber: '', name: 'CEFTRIAXONE 1GM IM/IV', category: 'injectable', form: 'SD', packSize: '1', par: '2' },
    { stockNumber: '', name: 'CYANOCOBALAMIN 1000MCG/ML', category: 'injectable', form: 'SD', packSize: '1', par: '12' },
    { stockNumber: '', name: 'DEXAMETHASONE 4MG/ML 1ML', category: 'injectable', form: 'SD', packSize: '1', par: '1' },
    { stockNumber: '', name: 'KENALOG 10MG/ML 1ML', category: 'injectable', form: 'MD', packSize: '1', par: '2' },
    { stockNumber: '', name: 'KENALOG 40MG/ML 1ML', category: 'injectable', form: 'SD', packSize: '1', par: '10' },
    { stockNumber: '', name: 'KETOROLAC 30MG/ML 1ML', category: 'injectable', form: 'SD', packSize: '1', par: '2' },
    { stockNumber: '', name: 'LIDOCAINE 1% 20ML', category: 'injectable', form: 'MD', packSize: '1', par: '4' },
    { stockNumber: '', name: 'LIDOCAINE 2% 20ML', category: 'injectable', form: 'MD', packSize: '1', par: '1' },
    { stockNumber: '', name: 'LIDOCAINE/EPI 1:100K 1% 20ML', category: 'injectable', form: 'MD', packSize: '1', par: '1' },
    { stockNumber: '', name: 'LIDOCAINE/EPI 1:100K 2% 20ML', category: 'injectable', form: 'MD', packSize: '1', par: '1' },
    { stockNumber: '', name: 'MEDROXYPROGESTERONE 150MG/ML', category: 'injectable', form: 'SD', packSize: '1', par: '1' },
    { stockNumber: '', name: 'METHYLPREDNISOLONE SOD SUCC 40MG', category: 'injectable', form: 'SD', packSize: '1', par: '1' },
    { stockNumber: '', name: 'ONDANSETRON 2MG/ML 2ML', category: 'injectable', form: 'SD', packSize: '1', par: '1' },
    { stockNumber: '', name: 'SODIUM CHLORIDE 0.9% 10ML', category: 'injectable', form: 'SD', packSize: '1', par: '10' },
    { stockNumber: '', name: 'WATER STERILE 10ML', category: 'injectable', form: 'SD', packSize: '1', par: '4' },

    // VACCINE
    { stockNumber: '', name: 'DIPHTHERIA/TETANUS/ACELLULAR PERTUSSIS (DAPTACEL)', category: 'vaccine', form: 'SF', packSize: '1', par: '1' },
    { stockNumber: '', name: 'DTaP-IPV-Hib HepB (VAXELIS)', category: 'vaccine', form: 'SD', packSize: '1', par: '10' },
    { stockNumber: '', name: 'DTaP-IPV (KINRIX)', category: 'vaccine', form: 'SDV', packSize: '1', par: '5' },
    { stockNumber: '', name: 'HAEMOPHILUS b CONJUGATE (ACTHIB)', category: 'vaccine', form: 'SD', packSize: '1', par: '1' },
    { stockNumber: '', name: 'HEPATITIS A 6 U/ML ADULT (HAVRIX)', category: 'vaccine', form: 'SD', packSize: '1', par: '5' },
    { stockNumber: '', name: 'HEPATITIS A 25 U/ML PEDIATRIC (VAQTA)', category: 'vaccine', form: 'SD', packSize: '1', par: '10' },
    { stockNumber: '', name: 'HEPATITIS B 5MCG (RECOMBIVAX)', category: 'vaccine', form: 'SD', packSize: '1', par: '1' },
    { stockNumber: '', name: 'HEPATITIS B 20MCG/ML ADULT (ENGERIX-B)', category: 'vaccine', form: 'SD', packSize: '1', par: '4' },
    { stockNumber: '', name: 'MEASLES/MUMPS/RUBELLA (MMR)', category: 'vaccine', form: 'SD', packSize: '1', par: '5' },
    { stockNumber: '', name: 'MENINGOCOCCAL ACWY (MENVEO)', category: 'vaccine', form: 'SD', packSize: '1', par: '10' },
    { stockNumber: '', name: 'MENINGOCOCCAL A/C/W/Y (PENBRAYA)', category: 'vaccine', form: 'SD', packSize: '1', par: '2' },
    { stockNumber: '', name: 'MENINGOCOCCAL GROUP B (TRUMENBA)', category: 'vaccine', form: 'SD', packSize: '1', par: '2' },
    { stockNumber: '', name: 'NIRSERUMAB-ALIP 50MG/0.5ML (BEYFORTUS)', category: 'vaccine', form: 'SD', packSize: '1', par: '1' },
    { stockNumber: '', name: 'NIRSERUMAB-ALIP 100MG/0.5ML (BEYFORTUS)', category: 'vaccine', form: 'SD', packSize: '1', par: '1' },
    { stockNumber: '', name: 'PAPILLOMAVIRUS 9HPV (GARDASIL 9)', category: 'vaccine', form: 'SF', packSize: '1', par: '10' },
    { stockNumber: '', name: 'PNEUMOCOCCAL CONJUGATE 20 VALENT (PREVNAR 20)', category: 'vaccine', form: 'SD', packSize: '1', par: '30' },
    { stockNumber: '', name: 'ROTAVIRUS (ROTATEQ)', category: 'vaccine', form: 'SS', packSize: '1', par: '10' },
    { stockNumber: '', name: 'RSV ADULT (ABRYSVO)', category: 'vaccine', form: 'SD', packSize: '1', par: '2' },
    { stockNumber: '', name: 'TETANUS/DIPHTHERIA/ACELLULAR PERTUSSIS (ADACEL)', category: 'vaccine', form: 'SD', packSize: '1', par: '30' },
    { stockNumber: '', name: 'TUBERCULIN SC (TUBERSOL)', category: 'vaccine', form: 'MD', packSize: '10dose/vial', par: '2' },
    { stockNumber: '', name: 'MMR & VARICELLA (PROQUAD)', category: 'vaccine', form: 'SD', packSize: '10', par: '2' },
    { stockNumber: '', name: 'VARICELLA (VARIVAX)', category: 'vaccine', form: 'SD', packSize: '10', par: '2' },
    { stockNumber: '', name: 'VARICELLA-ZOSTER GSK (SHINGRIX)', category: 'vaccine', form: 'SD', packSize: '1', par: '10' },
    { stockNumber: '', name: 'COVID VACCINE', category: 'vaccine', form: 'SD', packSize: '1', par: '15' }
];

// Category definitions
const categories = {
    'tablet-capsule': 'Tablet/Capsule',
    'topical': 'Topical',
    'ophthalmic': 'Ophthalmic',
    'liquids': 'Liquids',
    'nasal': 'Nasal',
    'respiratory': 'Respiratory',
    'insulin': 'Insulin',
    'emergency': 'Emergency Drug Box',
    'injectable': 'Injectable',
    'vaccine': 'Vaccine'
};

// Initialize the application
let items = [];
let currentFilter = 'all';
let currentCategory = 'all';
let currentSearch = '';
let currentOffice = null;
let offices = [];

// Check authentication
function checkAuth() {
    const session = JSON.parse(localStorage.getItem('userSession'));
    
    if (!session) {
        // No session, redirect to login
        window.location.href = 'login.html';
        return false;
    }
    
    // Update user info
    const userInfo = document.getElementById('userInfo');
    if (session.readOnly) {
        userInfo.textContent = `Logged in as: ${session.username} (Read-Only)`;
        document.getElementById('readOnlyBanner').style.display = 'block';
    } else {
        userInfo.textContent = `Logged in as: ${session.username} (${session.role || 'user'})`;
    }
    
    return session;
}

// Logout function
function logout() {
    localStorage.removeItem('userSession');
    window.location.href = 'login.html';
}

// Navigate to office selector
function goToOfficeSelector() {
    window.location.href = 'office-selector.html';
}

// Load offices from localStorage
function loadOffices() {
    const savedOffices = localStorage.getItem('medicalSupplyOffices');
    if (savedOffices) {
        offices = JSON.parse(savedOffices);
    } else {
        // Initialize with default office
        offices = [
            { 
                id: 'default', 
                name: 'MVHS New Hartford Medical Office', 
                items: medicalItems.map(item => ({
                    ...item,
                    expirationDates: [],
                    id: generateId()
                }))
            }
        ];
        saveOffices();
    }
}

// Save offices to localStorage
function saveOffices() {
    localStorage.setItem('medicalSupplyOffices', JSON.stringify(offices));
}

// Load data for current office
function loadOfficeData() {
    const currentOfficeId = localStorage.getItem('currentOfficeId') || 'default';
    
    // Find the current office
    currentOffice = offices.find(office => office.id === currentOfficeId);
    
    if (!currentOffice) {
        // If office not found, use default
        currentOffice = offices.find(office => office.id === 'default');
        if (!currentOffice) {
            // If no default office, create one
            currentOffice = {
                id: 'default',
                name: 'MVHS New Hartford Medical Office',
                items: medicalItems.map(item => ({
                    ...item,
                    expirationDates: [],
                    id: generateId()
                }))
            };
            offices.push(currentOffice);
            saveOffices();
        }
        localStorage.setItem('currentOfficeId', currentOffice.id);
    }
    
    // Migrate old item names to new ones
    if (currentOffice.items) {
        currentOffice.items.forEach(item => {
            if (item.name === 'SENSODYNE 2 OZ') {
                item.name = 'BENZOIN COMPOUND 2 OZ';
                item.stockNumber = '4089088';
            }
        });
        saveOffices();
    }
    
    // Update office header
    document.getElementById('officeName').textContent = currentOffice.name;
    
    items = currentOffice.items;
}

// Generate unique ID
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Save data to localStorage
function saveData() {
    // Update current office items
    currentOffice.items = items;
    
    // Find and update the office in the offices array
    const officeIndex = offices.findIndex(office => office.id === currentOffice.id);
    if (officeIndex !== -1) {
        offices[officeIndex] = currentOffice;
    } else {
        offices.push(currentOffice);
    }
    
    saveOffices();
}

// Calculate days until expiration
function getDaysUntilExpiration(expirationDate) {
    if (!expirationDate) return null;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const expDate = new Date(expirationDate);
    expDate.setHours(0, 0, 0, 0);
    const diffTime = expDate - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
}

// Get item status based on the earliest expiration date
function getItemStatus(expirationDates) {
    if (!expirationDates || expirationDates.length === 0) return 'no-date';
    
    // Find the earliest expiration date
    const earliestDate = expirationDates.reduce((earliest, current) => {
        const currentDays = getDaysUntilExpiration(current.date);
        const earliestDays = getDaysUntilExpiration(earliest.date);
        return currentDays < earliestDays ? current : earliest;
    });
    
    const days = getDaysUntilExpiration(earliestDate.date);
    if (days < 0) return 'expired';
    if (days <= 30) return 'expiring-soon';
    return 'good';
}

// Update statistics
function updateStats() {
    const total = items.length;
    let expired = 0;
    let expiringSoon = 0;
    let good = 0;

    items.forEach(item => {
        const status = getItemStatus(item.expirationDates);
        if (status === 'expired') expired++;
        else if (status === 'expiring-soon') expiringSoon++;
        else if (status === 'good') good++;
    });

    document.getElementById('totalItems').textContent = total;
    document.getElementById('expiredItems').textContent = expired;
    document.getElementById('expiringSoonItems').textContent = expiringSoon;
    document.getElementById('goodItems').textContent = good;
}

// Render items
function renderItems() {
    const container = document.getElementById('itemsContainer');
    container.innerHTML = '';

    // Filter items
    let filteredItems = items.filter(item => {
        // Category filter
        if (currentCategory !== 'all' && item.category !== currentCategory) {
            return false;
        }

        // Search filter
        if (currentSearch) {
            const searchLower = currentSearch.toLowerCase();
            if (!item.name.toLowerCase().includes(searchLower) && 
                !item.stockNumber.toLowerCase().includes(searchLower)) {
                return false;
            }
        }

        // Status filter
        if (currentFilter !== 'all') {
            const status = getItemStatus(item.expirationDates);
            if (currentFilter !== status) {
                return false;
            }
        }

        return true;
    });

    // Group by category
    const categories = {
        'tablet-capsule': 'Tablet/Capsule',
        'topical': 'Topical',
        'ophthalmic': 'Ophthalmic',
        'liquids': 'Liquids',
        'nasal': 'Nasal',
        'respiratory': 'Respiratory',
        'insulin': 'Insulin',
        'emergency': 'Emergency Drug Box Meds',
        'injectable': 'Injectable',
        'vaccine': 'Vaccine',
        'miscellaneous': 'Miscellaneous',
        'seasonal-flu': 'Seasonal Flu'
    };

    const groupedItems = {};
    filteredItems.forEach(item => {
        if (!groupedItems[item.category]) {
            groupedItems[item.category] = [];
        }
        groupedItems[item.category].push(item);
    });

    // Render each category
    Object.keys(groupedItems).forEach(categoryKey => {
        const categoryItems = groupedItems[categoryKey];
        const categorySection = document.createElement('div');
        categorySection.className = 'category-section';

        const categoryHeader = document.createElement('div');
        categoryHeader.className = 'category-header';
        categoryHeader.innerHTML = `
            <h2>${categories[categoryKey]}</h2>
            <span class="category-count">${categoryItems.length} items</span>
        `;
        categorySection.appendChild(categoryHeader);

        const itemsGrid = document.createElement('div');
        itemsGrid.className = 'items-grid';

        categoryItems.forEach(item => {
            const status = getItemStatus(item.expirationDates);
            
            // Create expiration dates list
            let expirationDatesHTML = '';
            if (item.expirationDates && item.expirationDates.length > 0) {
                expirationDatesHTML = '<div class="expiration-dates-list">';
                item.expirationDates.forEach((exp, index) => {
                    const days = getDaysUntilExpiration(exp.date);
                    let daysText = '';
                    if (days !== null) {
                        if (days < 0) {
                            daysText = `Expired ${Math.abs(days)} days ago`;
                        } else if (days === 0) {
                            daysText = 'Expires today';
                        } else if (days === 1) {
                            daysText = 'Expires tomorrow';
                        } else {
                            daysText = `${days} days remaining`;
                        }
                    }
                    
                    const session = JSON.parse(localStorage.getItem('userSession'));
                    const removeButton = session && !session.readOnly ? 
                        `<button class="btn btn-danger btn-small" onclick="removeExpirationDate('${item.id}', ${index})">Remove</button>` : 
                        '';
                    
                    expirationDatesHTML += `
                        <div class="expiration-date-item">
                            <span class="exp-date">${exp.date}</span>
                            <span class="exp-days ${status}">${daysText}</span>
                            ${removeButton}
                        </div>
                    `;
                });
                expirationDatesHTML += '</div>';
            } else {
                expirationDatesHTML = '<div class="no-expiration-dates">No expiration dates set</div>';
            }

            const itemCard = document.createElement('div');
            itemCard.className = `item-card ${status}`;
            itemCard.innerHTML = `
                <div class="item-header">
                    <div class="item-name">${item.name}</div>
                    <span class="status-badge ${status}">
                        ${status === 'expired' ? '⚠️ Expired' : 
                          status === 'expiring-soon' ? '⏰ Soon' : 
                          status === 'good' ? '✓ Good' : '📅 No Date'}
                    </span>
                </div>
                <div class="item-details">
                    <div class="item-detail">
                        <label>Stock #:</label>
                        <span>${item.stockNumber || 'N/A'}</span>
                    </div>
                    <div class="item-detail">
                        <label>Form:</label>
                        <span>${item.form || 'N/A'}</span>
                    </div>
                    <div class="item-detail">
                        <label>Pack Size:</label>
                        <span>${item.packSize || 'N/A'}</span>
                    </div>
                    <div class="item-detail">
                        <label>Par:</label>
                        <span>${item.par || 'N/A'}</span>
                    </div>
                </div>
                ${expirationDatesHTML}
                <div class="add-expiration-section" id="add-section-${item.id}">
                    <div class="expiration-input-container">
                        <input type="date" class="expiration-input" id="exp-input-${item.id}">
                        <button class="btn btn-secondary btn-small voice-btn" onclick="startVoiceInput('${item.id}')">🎤 Voice</button>
                    </div>
                    <button class="btn btn-primary btn-small" onclick="addExpirationDate('${item.id}')">➕ Add Expiration Date</button>
                </div>
            `;
            itemsGrid.appendChild(itemCard);
        });

        categorySection.appendChild(itemsGrid);
        container.appendChild(categorySection);
    });

    if (filteredItems.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <div style="font-size: 4em; margin-bottom: 20px;">📦</div>
                <h3>No items found</h3>
                <p>Try adjusting your filters or search criteria</p>
            </div>
        `;
    }

    updateStats();
    
    // Disable editing controls if in read-only mode
    const session = JSON.parse(localStorage.getItem('userSession'));
    if (session && session.readOnly) {
        // Disable all date inputs and add buttons
        document.querySelectorAll('.expiration-input').forEach(input => {
            input.disabled = true;
        });
        document.querySelectorAll('.add-expiration-section .btn-primary').forEach(btn => {
            btn.disabled = true;
            btn.style.opacity = '0.5';
            btn.style.cursor = 'not-allowed';
        });
        
        // Disable export and clear buttons
        const clearBtn = document.querySelector('button[onclick="clearAllData()"]');
        if (clearBtn) {
            clearBtn.disabled = true;
            clearBtn.style.opacity = '0.5';
            clearBtn.style.cursor = 'not-allowed';
        }
    }
}

// Add expiration date to an item
function addExpirationDate(itemId) {
    const session = JSON.parse(localStorage.getItem('userSession'));
    if (session && session.readOnly) {
        alert('You do not have permission to add expiration dates. Please login with an admin account.');
        return;
    }
    
    const item = items.find(i => i.id === itemId);
    if (item) {
        const dateInput = document.getElementById(`exp-input-${item.id}`);
        const dateValue = dateInput.value;
        
        if (!dateValue) {
            alert('Please select a date');
            return;
        }
        
        // Initialize expirationDates array if it doesn't exist
        if (!item.expirationDates) {
            item.expirationDates = [];
        }
        
        // Add new expiration date
        item.expirationDates.push({
            date: dateValue,
            id: generateId()
        });
        
        // Clear the input
        dateInput.value = '';
        
        saveData();
        renderItems();
    }
}

// Remove expiration date from an item
function removeExpirationDate(itemId, index) {
    const session = JSON.parse(localStorage.getItem('userSession'));
    if (session && session.readOnly) {
        alert('You do not have permission to remove expiration dates. Please login with an admin account.');
        return;
    }
    
    const item = items.find(i => i.id === itemId);
    if (item && item.expirationDates) {
        item.expirationDates.splice(index, 1);
        saveData();
        renderItems();
    }
}

// Voice input functionality
// Voice input functionality
function startVoiceInput(itemId) {
    const session = JSON.parse(localStorage.getItem('userSession'));
    if (session && session.readOnly) {
        alert('You do not have permission to use voice input. Please login to use this feature.');
        return;
    }
    
    // Check if browser supports speech recognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
        alert('Your browser does not support voice recognition. Please try Chrome, Edge, or Safari.');
        return;
    }
    
    // Create modal for voice input
    const modal = document.createElement('div');
    modal.id = 'voiceModal';
    modal.className = 'voice-modal';
    modal.innerHTML = `
        <div class="voice-content">
            <div class="voice-header">
                <h2>Voice Input</h2>
                <button class="btn btn-danger btn-small" onclick="closeVoiceInput()">✕</button>
            </div>
            <div class="voice-body">
                <div class="microphone-icon" id="micIcon">
                    🎤
                </div>
                <div class="voice-instructions">
                    <p>Click the microphone and say the expiration date</p>
                    <p class="voice-examples">Examples: "December 15th 2025", "12/15/2025", "March 2026"</p>
                </div>
                <button class="btn btn-primary btn-large" id="startListening" onclick="startListening('${itemId}')">
                    Start Listening
                </button>
                <div id="voiceResult" class="voice-result"></div>
                <div id="voiceTranscript" class="voice-transcript"></div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

// Start listening for voice input
function startListening(itemId) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    
    const micIcon = document.getElementById('micIcon');
    const startButton = document.getElementById('startListening');
    const transcriptDiv = document.getElementById('voiceTranscript');
    const resultDiv = document.getElementById('voiceResult');
    
    // Update UI to show listening state
    micIcon.classList.add('listening');
    startButton.disabled = true;
    startButton.textContent = 'Listening...';
    transcriptDiv.innerHTML = '<p class="listening-text">🎤 Listening...</p>';
    
    recognition.start();
    
    recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript;
        console.log('Voice input:', transcript);
        
        transcriptDiv.innerHTML = `<p><strong>You said:</strong> "${transcript}"</p>`;
        
        // Try to parse the date from the transcript
        const parsedDate = parseSpokenDate(transcript);
        
        if (parsedDate) {
            resultDiv.innerHTML = `
                <div class="voice-success">
                    <p>✅ Date Recognized!</p>
                    <p><strong>Expiration Date:</strong> ${parsedDate}</p>
                    <button class="btn btn-primary" onclick="useVoiceDate('${itemId}', '${parsedDate}')">Use This Date</button>
                    <button class="btn btn-secondary" onclick="startListening('${itemId}')">Try Again</button>
                </div>
            `;
        } else {
            resultDiv.innerHTML = `
                <div class="voice-error">
                    <p>⚠️ Could not recognize date</p>
                    <p>Please try again or say the date in a different format</p>
                    <button class="btn btn-secondary" onclick="startListening('${itemId}')">Try Again</button>
                </div>
            `;
        }
        
        // Reset UI
        micIcon.classList.remove('listening');
        startButton.disabled = false;
        startButton.textContent = 'Start Listening';
    };
    
    recognition.onerror = function(event) {
        console.error('Speech recognition error:', event.error);
        
        micIcon.classList.remove('listening');
        startButton.disabled = false;
        startButton.textContent = 'Start Listening';
        
        let errorMessage = 'An error occurred. Please try again.';
        if (event.error === 'no-speech') {
            errorMessage = 'No speech detected. Please try again.';
        } else if (event.error === 'not-allowed') {
            errorMessage = 'Microphone access denied. Please allow microphone access and try again.';
        }
        
        resultDiv.innerHTML = `
            <div class="voice-error">
                <p>⚠️ ${errorMessage}</p>
                <button class="btn btn-secondary" onclick="startListening('${itemId}')">Try Again</button>
            </div>
        `;
        transcriptDiv.innerHTML = '';
    };
    
    recognition.onend = function() {
        micIcon.classList.remove('listening');
        startButton.disabled = false;
        startButton.textContent = 'Start Listening';
    };
}

// Parse spoken date into YYYY-MM-DD format
function parseSpokenDate(spokenText) {
    const text = spokenText.toLowerCase().trim();
    
    // Remove common filler words
    const cleanText = text.replace(/\b(the|of|on|at|in)\b/g, '').trim();
    
    // Try to parse various date formats
    
    // Format: "December 15th 2025", "March 2026", etc.
    const monthNames = {
        'january': 0, 'jan': 0,
        'february': 1, 'feb': 1,
        'march': 2, 'mar': 2,
        'april': 3, 'apr': 3,
        'may': 4,
        'june': 5, 'jun': 5,
        'july': 6, 'jul': 6,
        'august': 7, 'aug': 7,
        'september': 8, 'sep': 8, 'sept': 8,
        'october': 9, 'oct': 9,
        'november': 10, 'nov': 10,
        'december': 11, 'dec': 11
    };
    
    // Try: "month day year" or "month year"
    for (const [monthName, monthIndex] of Object.entries(monthNames)) {
        const monthPattern = new RegExp(`${monthName}\\s+(\\d{1,2})(?:st|nd|rd|th)?\\s+(\\d{4})`, 'i');
        const match = cleanText.match(monthPattern);
        if (match) {
            const day = parseInt(match[1]);
            const year = parseInt(match[2]);
            const date = new Date(year, monthIndex, day);
            if (!isNaN(date.getTime())) {
                return date.toISOString().split('T')[0];
            }
        }
        
        // Try: "month year" (default to 1st of month)
        const monthYearPattern = new RegExp(`${monthName}\\s+(\\d{4})`, 'i');
        const monthYearMatch = cleanText.match(monthYearPattern);
        if (monthYearMatch) {
            const year = parseInt(monthYearMatch[1]);
            const date = new Date(year, monthIndex, 1);
            if (!isNaN(date.getTime())) {
                return date.toISOString().split('T')[0];
            }
        }
    }
    
    // Try: "MM/DD/YYYY" or "MM-DD-YYYY"
    const numericPattern = /(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})/;
    const numericMatch = cleanText.match(numericPattern);
    if (numericMatch) {
        const month = parseInt(numericMatch[1]) - 1;
        const day = parseInt(numericMatch[2]);
        const year = parseInt(numericMatch[3]);
        const date = new Date(year, month, day);
        if (!isNaN(date.getTime())) {
            return date.toISOString().split('T')[0];
        }
    }
    
    // Try: "YYYY-MM-DD"
    const isoPattern = /(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})/;
    const isoMatch = cleanText.match(isoPattern);
    if (isoMatch) {
        const year = parseInt(isoMatch[1]);
        const month = parseInt(isoMatch[2]) - 1;
        const day = parseInt(isoMatch[3]);
        const date = new Date(year, month, day);
        if (!isNaN(date.getTime())) {
            return date.toISOString().split('T')[0];
        }
    }
    
    // Try: "day month year" (e.g., "15 December 2025")
    for (const [monthName, monthIndex] of Object.entries(monthNames)) {
        const dayMonthPattern = new RegExp(`(\\d{1,2})(?:st|nd|rd|th)?\\s+${monthName}\\s+(\\d{4})`, 'i');
        const match = cleanText.match(dayMonthPattern);
        if (match) {
            const day = parseInt(match[1]);
            const year = parseInt(match[2]);
            const date = new Date(year, monthIndex, day);
            if (!isNaN(date.getTime())) {
                return date.toISOString().split('T')[0];
            }
        }
    }
    
    return null;
}

// Use voice-recognized date
function useVoiceDate(itemId, date) {
    const dateInput = document.getElementById(`exp-input-${itemId}`);
    if (dateInput) {
        dateInput.value = date;
        closeVoiceInput();
        addExpirationDate(itemId);
    }
}

// Close voice input modal
function closeVoiceInput() {
    const modal = document.getElementById('voiceModal');
    if (modal) {
        modal.remove();
    }
}function exportToCSV() {
    let csv = 'Stock Number,Item Name,Category,Form,Pack Size,Par,Expiration Dates,Status,Days Until Expiration\n';
    
    items.forEach(item => {
        const status = getItemStatus(item.expirationDates);
        const expDates = item.expirationDates ? item.expirationDates.map(exp => exp.date).join('; ') : '';
        const days = item.expirationDates && item.expirationDates.length > 0 ? 
            getDaysUntilExpiration(item.expirationDates[0].date) : 'N/A';
        csv += `"${item.stockNumber}","${item.name}","${item.category}","${item.form}","${item.packSize}","${item.par}","${expDates}","${status}","${days !== null ? days : 'N/A'}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `medical-supplies-${currentOffice.name.replace(/[^a-z0-9]/gi, '_')}-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
}

// Export to JSON
function exportToJSON() {
    const dataStr = JSON.stringify(items, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `medical-supplies-${currentOffice.name.replace(/[^a-z0-9]/gi, '_')}-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
}

// Clear all data
function clearAllData() {
    const session = JSON.parse(localStorage.getItem('userSession'));
    if (session && session.readOnly) {
        alert('You do not have permission to clear data. Please login with an admin account.');
        return;
    }
    
    if (confirm('Are you sure you want to clear all expiration dates? This action cannot be undone.')) {
        items = medicalItems.map(item => ({
            ...item,
            expirationDates: [],
            id: generateId()
        }));
        saveData();
        renderItems();
    }
}

// Populate category selector dropdown
function populateCategorySelector() {
    const selector = document.getElementById('categorySelector');
    
    // Clear existing options except the first one
    selector.innerHTML = '<option value="">-- Select a category first --</option>';
    
    // Add category options
    Object.keys(categories).forEach(categoryKey => {
        const categoryItems = items.filter(item => item.category === categoryKey);
        
        if (categoryItems.length > 0) {
            const option = document.createElement('option');
            option.value = categoryKey;
            option.textContent = `${categories[categoryKey]} (${categoryItems.length} items)`;
            selector.appendChild(option);
        }
    });
}

// Populate item selector dropdown based on selected category
function populateItemSelector(selectedCategory) {
    const selector = document.getElementById('itemSelector');
    
    if (!selectedCategory) {
        selector.innerHTML = '<option value="">-- Select a category first --</option>';
        selector.disabled = true;
        return;
    }
    
    // Clear existing options
    selector.innerHTML = '<option value="">-- Select an item --</option>';
    selector.disabled = false;
    
    // Filter items by selected category and sort by name
    const categoryItems = items
        .filter(item => item.category === selectedCategory)
        .sort((a, b) => a.name.localeCompare(b.name));
    
    // Add item options
    categoryItems.forEach(item => {
        const option = document.createElement('option');
        option.value = item.id;
        option.textContent = item.name;
        selector.appendChild(option);
    });
}

// Handle category selection
function handleCategorySelection(categoryKey) {
    populateItemSelector(categoryKey);
    // Reset item selector
    document.getElementById('itemSelector').value = '';
}

// Handle item selection from dropdown
function handleItemSelection(itemId) {
    if (!itemId) return;
    
    // Find the item card in the DOM
    const itemCards = document.querySelectorAll('.item-card');
    let targetCard = null;
    
    itemCards.forEach(card => {
        // Find card with matching item ID
        const item = items.find(i => i.id === itemId);
        if (item) {
            const itemNameElement = card.querySelector('.item-name');
            if (itemNameElement && itemNameElement.textContent === item.name) {
                targetCard = card;
            }
        }
    });
    
    if (targetCard) {
        // Scroll to the item with smooth animation
        targetCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Highlight the card temporarily
        targetCard.style.transform = 'scale(1.05)';
        targetCard.style.boxShadow = '0 10px 30px rgba(102, 126, 234, 0.4)';
        
        setTimeout(() => {
            targetCard.style.transform = '';
            targetCard.style.boxShadow = '';
        }, 2000);
        
        // Focus on the expiration date input
        const input = targetCard.querySelector('.expiration-input');
        if (input) {
            setTimeout(() => input.focus(), 500);
        }
    }
}

// Event listeners
document.getElementById('searchInput').addEventListener('input', (e) => {
    currentSearch = e.target.value;
    renderItems();
});

document.getElementById('categoryFilter').addEventListener('change', (e) => {
    currentCategory = e.target.value;
    renderItems();
});

document.querySelectorAll('.filter-tag').forEach(tag => {
    tag.addEventListener('click', () => {
        document.querySelectorAll('.filter-tag').forEach(t => t.classList.remove('active'));
        tag.classList.add('active');
        currentFilter = tag.dataset.filter;
        renderItems();
    });
});

// Event listener for category selector
document.getElementById('categorySelector').addEventListener('change', (e) => {
    handleCategorySelection(e.target.value);
});

// Event listener for item selector
document.getElementById('itemSelector').addEventListener('change', (e) => {
    handleItemSelection(e.target.value);
});

// Set default active filter
document.querySelector('.filter-tag[data-filter="all"]').classList.add('active');

// Initialize app
checkAuth(); // Check authentication first
loadOffices();
loadOfficeData();
populateCategorySelector();
renderItems();