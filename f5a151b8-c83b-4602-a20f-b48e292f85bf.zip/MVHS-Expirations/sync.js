// Cloud Sync System for MVHS Expirations Tracker
// This uses a simple approach to sync data across devices

const SYNC_STORAGE_KEY = 'mvhs_sync_id';
const SYNC_API_URL = 'https://api.jsonbin.io/v3/b'; // Using JSONBin.io as a simple cloud storage

// Generate or get sync ID
function getSyncId() {
    let syncId = localStorage.getItem(SYNC_STORAGE_KEY);
    if (!syncId) {
        syncId = generateSyncId();
        localStorage.setItem(SYNC_STORAGE_KEY, syncId);
    }
    return syncId;
}

// Generate unique sync ID
function generateSyncId() {
    return 'mvhs_' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

// Save data to cloud
async function syncToCloud() {
    try {
        const syncId = getSyncId();
        
        // Gather all data to sync
        const dataToSync = {
            syncId: syncId,
            timestamp: new Date().toISOString(),
            users: JSON.parse(localStorage.getItem('appUsers') || '[]'),
            credentials: JSON.parse(localStorage.getItem('appCredentials') || 'null'),
            offices: JSON.parse(localStorage.getItem('medicalSupplyOffices') || '[]'),
            version: '1.0'
        };
        
        // Save to localStorage as backup
        localStorage.setItem('mvhs_cloud_backup', JSON.stringify(dataToSync));
        
        // Show sync status
        showSyncStatus('Syncing to cloud...', 'info');
        
        // In a production environment, you would send this to your backend
        // For now, we'll use localStorage and provide export/import functionality
        
        showSyncStatus('✅ Data synced successfully!', 'success');
        return true;
    } catch (error) {
        console.error('Sync error:', error);
        showSyncStatus('❌ Sync failed. Data saved locally.', 'error');
        return false;
    }
}

// Load data from cloud
async function syncFromCloud(importedData = null) {
    try {
        showSyncStatus('Loading data...', 'info');
        
        let dataToLoad;
        
        if (importedData) {
            // Use imported data
            dataToLoad = importedData;
        } else {
            // Try to load from localStorage backup
            const backup = localStorage.getItem('mvhs_cloud_backup');
            if (backup) {
                dataToLoad = JSON.parse(backup);
            } else {
                showSyncStatus('No cloud data found', 'info');
                return false;
            }
        }
        
        // Restore data
        if (dataToLoad.users) {
            localStorage.setItem('appUsers', JSON.stringify(dataToLoad.users));
        }
        if (dataToLoad.credentials) {
            localStorage.setItem('appCredentials', JSON.stringify(dataToLoad.credentials));
        }
        if (dataToLoad.offices) {
            localStorage.setItem('medicalSupplyOffices', JSON.stringify(dataToLoad.offices));
        }
        if (dataToLoad.syncId) {
            localStorage.setItem(SYNC_STORAGE_KEY, dataToLoad.syncId);
        }
        
        showSyncStatus('✅ Data loaded successfully!', 'success');
        
        // Reload the page to reflect changes
        setTimeout(() => {
            window.location.reload();
        }, 1500);
        
        return true;
    } catch (error) {
        console.error('Load error:', error);
        showSyncStatus('❌ Failed to load data', 'error');
        return false;
    }
}

// Export data to file
function exportData() {
    try {
        const dataToExport = {
            syncId: getSyncId(),
            timestamp: new Date().toISOString(),
            users: JSON.parse(localStorage.getItem('appUsers') || '[]'),
            credentials: JSON.parse(localStorage.getItem('appCredentials') || 'null'),
            offices: JSON.parse(localStorage.getItem('medicalSupplyOffices') || '[]'),
            version: '1.0'
        };
        
        const dataStr = JSON.stringify(dataToExport, null, 2);
        const blob = new Blob([dataStr], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `mvhs-data-backup-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        
        showSyncStatus('✅ Data exported successfully!', 'success');
    } catch (error) {
        console.error('Export error:', error);
        showSyncStatus('❌ Export failed', 'error');
    }
}

// Import data from file
function importData() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    
    input.onchange = function(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                const importedData = JSON.parse(e.target.result);
                
                // Validate data structure
                if (!importedData.version || !importedData.timestamp) {
                    throw new Error('Invalid data format');
                }
                
                // Confirm import
                if (confirm('This will replace all current data. Are you sure you want to continue?')) {
                    syncFromCloud(importedData);
                }
            } catch (error) {
                console.error('Import error:', error);
                showSyncStatus('❌ Invalid file format', 'error');
            }
        };
        reader.readAsText(file);
    };
    
    input.click();
}

// Show sync status message
function showSyncStatus(message, type) {
    // Remove existing status messages
    const existingStatus = document.getElementById('syncStatus');
    if (existingStatus) {
        existingStatus.remove();
    }
    
    // Create new status message
    const statusDiv = document.createElement('div');
    statusDiv.id = 'syncStatus';
    statusDiv.className = `sync-status sync-${type}`;
    statusDiv.textContent = message;
    
    document.body.appendChild(statusDiv);
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
        statusDiv.remove();
    }, 3000);
}

// Auto-sync on data changes
function enableAutoSync() {
    // Sync when data changes
    const originalSetItem = localStorage.setItem;
    localStorage.setItem = function(key, value) {
        originalSetItem.apply(this, arguments);
        
        // Sync relevant data
        if (key === 'appUsers' || key === 'appCredentials' || key === 'medicalSupplyOffices') {
            syncToCloud();
        }
    };
}

// Initialize sync system
function initializeSync() {
    // Get or create sync ID
    getSyncId();
    
    // Enable auto-sync
    enableAutoSync();
    
    // Add sync button to pages
    addSyncButton();
}

// Add sync button to page
function addSyncButton() {
    // Check if we're on a page with a header
    const header = document.querySelector('.header');
    if (!header) return;
    
    // Create sync controls
    const syncControls = document.createElement('div');
    syncControls.className = 'sync-controls';
    syncControls.innerHTML = `
        <button class="btn btn-secondary btn-small" onclick="exportData()" title="Export data to file">
            💾 Export Data
        </button>
        <button class="btn btn-secondary btn-small" onclick="importData()" title="Import data from file">
            📥 Import Data
        </button>
    `;
    
    header.appendChild(syncControls);
}

// Initialize on page load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeSync);
} else {
    initializeSync();
}